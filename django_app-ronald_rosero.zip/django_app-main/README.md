pip list# django_app
Este es un repositorio de practica de una app fullstack de Django
